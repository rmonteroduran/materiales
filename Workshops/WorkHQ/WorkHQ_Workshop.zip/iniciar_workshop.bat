@echo off
title SS&C WorkHQ Workshop
start "" index.html
