@echo off
title Clase 01
start "" "clase_01_introduccion_entornos_virtualizados.html"
