@echo off
title Clase 02
start "" "clase_02_arquitecturas_vm_contenedores.html"
